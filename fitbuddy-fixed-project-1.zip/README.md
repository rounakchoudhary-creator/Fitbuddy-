# FitBuddy AI (Fixed Version)

Run:

pip install -r requirements.txt
uvicorn main:app --reload

Open:
http://127.0.0.1:8000